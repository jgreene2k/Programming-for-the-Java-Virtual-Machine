package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Lor extends NoArgsSequence
{
    public Lor()
    {
        super(0, -2, opc_lor);
    }
}
