package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class I2f extends NoArgsSequence
{
    public I2f()
    {
        super(0, 0, opc_i2f);
    }
}
