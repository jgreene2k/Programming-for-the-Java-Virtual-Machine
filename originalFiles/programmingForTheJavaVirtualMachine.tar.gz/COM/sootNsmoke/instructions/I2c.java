package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class I2c extends NoArgsSequence
{
    public I2c()
    {
        super(0, 0, opc_i2c);
    }
}
