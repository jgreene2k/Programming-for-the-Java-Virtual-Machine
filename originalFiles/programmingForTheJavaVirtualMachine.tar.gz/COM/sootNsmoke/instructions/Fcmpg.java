package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Fcmpg extends NoArgsSequence
{
    public Fcmpg()
    {
        super(0, -1, opc_fcmpg);
    }
}
