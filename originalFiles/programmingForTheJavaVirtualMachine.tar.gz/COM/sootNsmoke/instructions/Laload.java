package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Laload extends NoArgsSequence
{
    public Laload()
    {
        super(0, 0, opc_laload);
    }
}
