package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Daload extends NoArgsSequence
{
    public Daload()
    {
        super(0, 0, opc_daload);
    }
}
