package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Monitorenter  extends  NoArgsSequence
{
    public Monitorenter () { super(0, -1, opc_monitorenter); }
}
