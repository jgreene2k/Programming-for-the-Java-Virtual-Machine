package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class F2i extends NoArgsSequence
{
    public F2i()
    {
        super(0, 0, opc_f2i);
    }
}
