package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Land extends NoArgsSequence
{
    public Land()
    {
        super(0, -2, opc_land);
    }
}
