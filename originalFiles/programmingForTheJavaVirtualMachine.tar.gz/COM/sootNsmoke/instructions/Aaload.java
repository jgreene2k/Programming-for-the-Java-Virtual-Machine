package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Aaload extends NoArgsSequence
{
    public Aaload()
    {
        super(0, -1, opc_aaload);
    }
}
