package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Ior extends NoArgsSequence
{
    public Ior()
    {
        super(0, -1, opc_ior);
    }
}
