package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Dcmpl extends NoArgsSequence
{
    public Dcmpl()
    {
        super(0, -3, opc_dcmpl);
    }
}
