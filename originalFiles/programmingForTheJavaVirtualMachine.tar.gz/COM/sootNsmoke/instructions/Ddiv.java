package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Ddiv extends NoArgsSequence
{
    public Ddiv()
    {
        super(0, -2, opc_ddiv);
    }
}
